To run this application, follow following steps -

Note - Before heading to given steps, extract the folder and navigate yourself to 'Chart Drawing API'
(1)Create a Database called 'Draw_a_chart' in your MySQL-databases.

(2)Restore MySQL data into this 'Draw_a_chart' database using mysqldump.sql file(given in parent folder).

(3)Navigate to './NodeJS/app/db.config.js' and put your user-name and password of MySQL database.

(4)Make sure that port no. 3000 and 9000 on localhost are free and can be used for another application.

(5)Navigate to NodeJS folder and run $npm start 
Note - Make sure you give root privileges if required.

(6)Navigate to reactjs folder and run $npm start 
Note - Make sure you give root privileges if required.

(7)Open browser and run https://localhost:3000

Note - your application is ready.
Managed and Created By - Manish Sharma