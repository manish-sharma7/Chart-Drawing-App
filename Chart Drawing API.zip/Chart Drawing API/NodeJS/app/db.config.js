module.exports = {
  HOST: "localhost",
  USER: "manish", //Enter your username of mysql database
  PASSWORD: "Manish123%", //Enter your password of mysql database
  DB: "Draw_a_chart",
};
